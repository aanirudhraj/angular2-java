# ng2boot
A minimal Angular2 and Spring Boot starter project

The steps to create this project are described in detail in this blog post: https://blog.jdriven.com/2016/12/angular2-spring-boot-getting-started
