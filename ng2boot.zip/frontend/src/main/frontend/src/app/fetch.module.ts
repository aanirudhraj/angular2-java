export class fetch {  
necaId: string;
state: string;
zoneId:string; 
msaInd:string; 
bandLow: string;
bandHigh: string;
lengthOfTerm: string;
lcrsCostEleId: string;
rate:string; 
lotDefault:string;
}
