import { Component } from '@angular/core';  
import { MovieService } from './movie.service';  
import { fetch } from './fetch.module';

@Component({
  selector: 'my-app',
  providers: [MovieService],
  templateUrl: './app.component.html',
  styleUrls:['./app.component.css','./animate.min.css']
})


export class AppComponent {


  response: fetch;
  dataList:any = [];
  search: string;
  


  constructor(private movieService: MovieService) {}

  getNew(m:any) {
    this.search = m;
    this.getData();
  }



  getData() {

      this.movieService.getList(this.search)
      .then(dataList => this.dataList = dataList );
  }


}